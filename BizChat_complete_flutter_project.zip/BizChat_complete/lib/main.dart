import 'package:flutter/material.dart';

void main() => runApp(const BizChatApp());

class BizChatApp extends StatelessWidget {
  const BizChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BizChat',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF128C7E)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    ChatPage(),
    CustomersPage(),
    ProductsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BizChat', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert)),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'චැට්'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'පාරිභෝගික'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'භාණ්ඩ'),
        ],
      ),
      floatingActionButton: index == 0
          ? FloatingActionButton(
              onPressed: () {},
              child: const Icon(Icons.chat),
            )
          : null,
    );
  }
}

class ChatPage extends StatelessWidget {
  const ChatPage({super.key});

  @override
  Widget build(BuildContext context) {
    final chats = [
      ('නිමල්', 'අද ඇණවුම එවන්න පුළුවන්ද?', '10:42'),
      ('කසුන්', 'හරි, ස්තුතියි!', '09:18'),
      ('සඳුනි', 'භාණ්ඩ ලැයිස්තුව එවන්න.', 'ඊයේ'),
    ];
    return ListView(
      children: [
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text('ව්‍යාපාරික පණිවිඩ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
        ...chats.map((c) => ListTile(
          leading: CircleAvatar(child: Text(c.$1.substring(0, 1))),
          title: Text(c.$1, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(c.$2),
          trailing: Text(c.$3, style: const TextStyle(fontSize: 12)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatDetailPage(name: c.$1))),
        )),
      ],
    );
  }
}

class ChatDetailPage extends StatefulWidget {
  final String name;
  const ChatDetailPage({super.key, required this.name});
  @override
  State<ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  final controller = TextEditingController();
  final messages = <String>['ආයුබෝවන්! BizChat වෙත සාදරයෙන් පිළිගනිමු.'];

  void send() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add(text);
      controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (_, i) => Align(
                alignment: Alignment.centerRight,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(messages[i]),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(child: TextField(
                  controller: controller,
                  decoration: const InputDecoration(
                    hintText: 'පණිවිඩයක් ලියන්න...',
                    border: OutlineInputBorder(),
                  ),
                  onSubmitted: (_) => send(),
                )),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: send, icon: const Icon(Icons.send)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class CustomersPage extends StatelessWidget {
  const CustomersPage({super.key});
  @override
  Widget build(BuildContext context) {
    final customers = ['නිමල්', 'කසුන්', 'සඳුනි', 'රුවන්'];
    return ListView(
      children: [
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text('පාරිභෝගිකයන්', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
        ...customers.map((n) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(n),
          subtitle: const Text('පාරිභෝගික'),
          trailing: const Icon(Icons.chevron_right),
        )),
      ],
    );
  }
}

class ProductsPage extends StatelessWidget {
  const ProductsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final products = [
      ('කමිසය', 'රු. 2,500'),
      ('කලිසම', 'රු. 3,500'),
      ('ටී-ෂර්ට්', 'රු. 1,500'),
    ];
    return ListView(
      children: [
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text('භාණ්ඩ ලැයිස්තුව', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
        ...products.map((p) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.shopping_bag)),
          title: Text(p.$1),
          subtitle: Text(p.$2),
          trailing: const Icon(Icons.edit_outlined),
        )),
      ],
    );
  }
}
