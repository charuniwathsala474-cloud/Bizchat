# BizChat

BizChat is a Flutter starter app inspired by business messaging apps.

Phone-only build target:
- GitHub repository
- Codemagic cloud build
- Android APK

This version is a UI starter. Real accounts, cloud chat, image upload,
notifications, products/orders database, and auto-replies can be added later.
